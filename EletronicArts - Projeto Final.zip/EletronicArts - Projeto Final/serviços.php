<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SERVIÇOS</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ea.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Moderna - v2.0.0
  * Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="index.php"><span>Eletronic Arts</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu float-right d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="sistemaerp.php">Sistema ERP</a></li>
          <li class="active"><a href="serviços.php">Serviços</a></li>
          <li><a href="loja.php">Loja</a></li>
          <li><a href="time.php">Nosso Time</a></li>
          <li><a href="blog.php">Notícias</a></li>
          <li><a href="contato.php">Contate-nos</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Our Services Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Todos os cursos</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Nossos Serviços</li>
          </ol>
        </div>

      </div>
    </section><!-- End Our Services Section -->

    <!-- ======= Services Section ======= -->
    <section class="services">
      <div class="container">

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4 class="title"><a href="">Suporte de TI remoto</a></h4>
              <p class="description">Com a contratação de um plano a empresa passa a ter muito mais segurança, confiança e estabilidade em sua área de informática.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box icon-box-cyan">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="">Eletricidade básica</a></h4>
              <p class="description">Todo mundo gosta de economizar. Para gastar menos com a conta de luz, você precisa consumir energia elétrica de forma eficiente.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box icon-box-green">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4 class="title"><a href="">Configuração e Manutenção de PC</a></h4>
              <p class="description">A tecnologia é um setor que evolui constantemente, com isso atualizações para melhorar falhas e processos de manutenção de computadores vem junto.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box icon-box-blue">
              <div class="icon"><i class="bx bx-world"></i></div>
              <h4 class="title"><a href="">Administração de Rede de Computadores</a></h4>
              <p class="description">Administram os endereços IP's e nomes de domínio da unidade, configuram e valida o gateway/roteador de acesso à internet.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Why Us Section ======= -->
    <section class="why-us section-bg" data-aos="fade-up" date-aos-delay="200">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 video-box">
            <img src="assets/img/why-us.jpg" class="img-fluid" alt="">
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-6 d-flex flex-column justify-content-center p-5">

            <div class="icon-box">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">QUEM SOMOS?</a></h4>
              <p class="description">Somos uma Empresa focada em Tecnologia, que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="bx bx-gift"></i></div>
              <h4 class="title"><a href="">Benefícios</a></h4>
              <p class="description">Temos os melhores profissionais do mercado, o melhor custo benefício e o melhor atendimento, fácil, rápido e seguro.</p>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Service Details Section ======= -->
    <section class="service-details">
      <div class="container">

        <div class="row">
          <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/service-details-1.jpg" alt="...">
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="#">Serviços em eletricidade e instalações elétricas</a></h5>
                <p class="card-text">Realiza-se projeto para instalações elétricas em residências, edifícios e condomínios horizontais. 
                  Um projeto completo pode incluir: 
                  instalação elétrica, projeto luminotécnico, telefone, sistema de proteção contra descargas atmosféricas (spda), iluminação de emergência, circuitos de Tv a cabo e interfone/porteiro eletrônico.</p>
                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Leia mais sobre</a></div>
              </div>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/service-details-2.jpg" alt="...">
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="#">Teste de rede</a></h5>
                <p class="card-text">Um teste de rede funciona por meio de um algoritmo, 
                  que calcula as taxas de download, upload e ping da sua internet, 
                  enviando e recebendo pequenos pacotes de dados para obter informações sobre a sua conexão.</p>
                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Leia mais sobre</a></div>
              </div>
            </div>

          </div>
          <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/service-details-3.jpg" alt="...">
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="#">Suporte de TI remoto</a></h5>
                <p class="card-text">Para empresas, a contratação de planos de suporte de TI é a melhor solução, 
                  pois nunca sabemos quando um problema de informática pode surgir. 
                  Mas com a contratação do plano de serviços, é possível solucionar qualquer problema com muita facilidade e agilidade.</p>
                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Leia mais sobre</a></div>
              </div>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/service-details-4.jpg" alt="...">
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="#">Administração de Rede</a></h5>
                <p class="card-text">Elaboram projetos de redes (física e lógica), analisam e validam projetos elaborados por terceiros, 
                  administram os endereços IP's e nomes de domínio da unidade, configuram e 
                  valida o gateway/roteador de acesso à internet e buscam constantemente a otimização dos recursos computacionais, 
                  garantindo o bom uso e a segurança dos recursos.</p>
                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Leia mais sobre</a></div>
              </div>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/service-details-4.jpg" alt="...">
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="#">Configuração e Manutenção de PC</a></h5>
                <p class="card-text">A tecnologia é um setor que evolui constantemente desenvolvendo um alto número de novidades de mercado. 
                  Com isso, atualizações para melhorar falhas e processos de manutenção de computadores vem junto. 
                  Então, é fundamental que um time de suporte de TI acompanhe essas novidades, para que a empresa não fique para trás.</p>
                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Leia mais sobre</a></div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Service Details Section -->

    <!-- ======= Pricing Section ======= -->
    <section class="pricing section-bg" data-aos="fade-up">
      <div class="container">

        <div class="section-title">
          <h2>Precificação</h2>
          <p>Espero que tenham gostado dos nossos produtos e de nossos preços!
            Logo abaixo temos os serviços que realizamos a domicílio e em nossa empresa e
            para mais dúvidas e detalhes sobre nossos trabalhos ou serviços, entre em 
            contato conosco! 
          </p>
        </div>

        <div class="row no-gutters">

          <div class="col-lg-4 box">
            <h3>Manutenção de Computadores, Cabiamento e instalação de redes</h3>
            <h4>R$150<span>por pessoa</span></h4>
            <ul>
              <li><i class="bx bx-check"></i> Manutenção completa de computadores: Limpeza, Troca da pasta térmica, Teste de voltagem, entre outros;</li>
              <li><i class="bx bx-check"></i> Cabiamento completo dos computadores: Troca dos fios, Teste de cabo de rede, Manutenção da fiação, entre outros;</li>
              <li><i class="bx bx-check"></i> Instalação de redes: Patch Panel, Cripagem, Conexão local e WiFi, entre outros;</li>
              <li class="na"><i class="bx bx-x"></i> <span>Instalação de Softwares: Windows 10, Atualização da BIOS, Pacote Office, Troca de periféricos;</span></li>
              <li class="na"><i class="bx bx-x"></i> <span>Manutenção em servidores, Manutenção em equipamentos que não sejam relacionados a computadores ou a Cabiamento;</span></li>
              <li class="na"><i class="bx bx-x"></i> <span>Montagem de computadores;</span></li>
              
            </ul>
            <a href="#" class="get-started-btn">Solicite agora nossos serviços</a>
          </div>

          <div class="col-lg-4 box featured">
            <h3>Manutenção Elétrica Residencial</h3>
            <h4>R$3.500<span>por tamanho da casa</span></h4>
            <ul>
              <li><i class="bx bx-check"></i> Manutenção Elétrica Residencial: Troca da fiação, Teste de voltagem, Instalação elétrica;</li>
              <li><i class="bx bx-check"></i> Automatização Residencial: Automatizar portões, portas, salas, entre outros;</li>
              <li><i class="bx bx-check"></i> Instalação de segurança: Instalação de câmeras, alarmes, sensores, travas eletrônicas;</li>
              <li><i class="bx bx-check"></i> Instalação de tomadas, interruptores, lustres, lâmpadas;</li>
              <li><i class="bx bx-check"></i> Manutenção de luminárias, reatores, iluminação para jardins;</li>
              <li><i class="bx bx-check"></i> Manutenção de torneiras elétricas, aquecedores, secadores;</li>
              <li><i class="bx bx-check"></i> Manutenção de coifas, exaustores, ventiladores de teto;</li>
              <li><i class="bx bx-check"></i> Manutenção de campainha e interfone;</li>
              <li><i class="bx bx-check"></i> Substituição de fiação residencial e comercial;</li>
              <li><i class="bx bx-check"></i> Instalação e relocação de linhas e ramais telefônicos;</li>
              <li class="na"><i class="bx bx-x"></i> <span>Não trabalhamos com Eletrodomésticos, não fazemos automoções em outros equipamentos que não sejam os citados acima.</span></li>
            </ul>
            <a href="#" class="get-started-btn">Solicite agora nossos serviços</a>
          </div>

          <div class="col-lg-4 box">
            <h3>Suporte de TI remoto</h3>
            <h4>R$600<span>por PC</span></h4>
            <ul>
              <li><i class="bx bx-check"></i> Backup em nuvem;</li>
              <li><i class="bx bx-check"></i> Desenvolvimento de sites;</li>
              <li><i class="bx bx-check"></i> Outsourcing de TI;</li>
              <li><i class="bx bx-check"></i> Segurança da informação;</li>
              <li><i class="bx bx-check"></i> Suporte técnico remoto;</li>
              <li><i class="bx bx-check"></i> Proteção de rede;</li>
              <li><i class="bx bx-check"></i> Configuração remota de impressora;</li>
              <li><i class="bx bx-check"></i> Suporte técnico remoto;</li>
              <li><i class="bx bx-check"></i> Instalação e configuração de softwares;</li>
              <li><i class="bx bx-check"></i> Formatação;</li>
              <li><i class="bx bx-check"></i> Configuração de roteador wifi;</li>
              <li><i class="bx bx-check"></i> Manutenção em casos de problemas com lentidão em equipamentos;</li>
              <li><i class="bx bx-check"></i> Troubleshooting de servidores;</li>
              <li><i class="bx bx-check"></i> Atualização de servidores e PC's;</li>
              <li><i class="bx bx-check"></i> Remoção de vírus de computador;</li> 
            </ul>
            <a href="#" class="get-started-btn">Solicite agora nossos serviços</a>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h4>Quer receber mais notícias sobre nossos produtos ou relacionados? Inscreva-se em nosso site!</h4>
            <p>Para mais dúvidas, elogios ou críticas nos mande um e-mail</p>
          </div>
          <div class="col-lg-6">
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Links úteis</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="sistemaerp.php">Sistema ERP</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="serviços.php">Serviços</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Nossos Serviços</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Suporte de TI remoto</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Eletricidade Básica</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Configuração e Manutenção de PC</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Administração de rede de computadores</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contate-nos</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Sobre a Eletronic Arts</h3>
            <p>Somos uma Empresa focada em Tecnologia, que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eletronic Arts</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/ -->

      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>