<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> Notícias </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ea.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Moderna - v2.0.0
  * Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="index.php"><span>Eletronic Arts</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu float-right d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="sistemaerp.php">Sistema ERP</a></li>
          <li><a href="serviços.php">Serviços</a></li>
          <li><a href="loja.php">Loja</a></li>
          <li><a href="time.php">Nosso time</a></li>
          <li class="active"><a href="blog.php">Notícias</a></li>
          <li><a href="contato.php">Contate-nos</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Blog Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Notícias</h2>

          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Nossas Notícias</li>
          </ol>
        </div>

      </div>
    </section><!-- End Blog Section -->

    <!-- ======= Blog Section ======= -->
    <section class="blog" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">
      <div class="container">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry">

              <div class="entry-img">
                <img src="assets/img/msp.png" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.php">MSP Summit: tudo sobre o evento para profissionais de TI</a>
                </h2>

              <div class="entry-meta">
              </div>

              <div class="entry-content">
                <p>Você conhece o MSP Summit? Ele é um encontro anual que busca fomentar networking e troca de conhecimento entre profissionais de Tecnologia da Informação (TI) e contou com a participação de 1,2 mil inscritos em 2021. Neste ano, o evento volta ao seu formato presencial, que acontecerá em São Paulo.
                  O recente relatório da Brazilian Software Market Study — Overview and Trends 2022 divulgou que a projeção de crescimento para o mercado de TI em 2022 é de 14,3% e, além disso, os investimentos no setor continuam em expansão. 
                  Assim, a Pesquisa anual do uso de TI 2022, conduzida pela Fundação Getulio Vargas (FGV), apontou um crescimento nos investimentos que as empresas estão fazendo no setor de TI. Em 2021, a média do volume de investimentos em TI por essas empresas foi de 8,2%, enquanto o realizado neste ano foi de 8,7%.                 
                </p>
                <div class="read-more">
                  <a href="blog-single.php">Leia Mais</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <article class="entry">

              <div class="entry-img">
                <img src="assets/img/tic.png" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.php">Mercado brasileiro de TIC vai crescer em 2022 com nuvem e 5G</a>
              </h2>

              <div class="entry-meta">

              </div>

              <div class="entry-content">
                <p>
                  O mercado brasileiro de Tecnologias da Informação e Comunicação (TIC) deve crescer e aproveitar novas tendências de mercado em 2022. Essa é a previsão de um novo relatório da empresa de consultoria e inteligência IDC Brasil.

O estudo aponta que os segmentos de TI (corporativo ou para consumidor) e telecomunicações devem apresentar alta, fazendo com que o setor cresça 8,2% no ano em média.

Por outro lado, a escassez de chips ainda será sentida no Brasil. O país passará por "algum impacto pelo atraso ou restrição de dispositivos que utilizam chips de gerações anteriores e não tiveram aportes recentes", diz o estudo.
                </p>
                <div class="read-more">
                  <a href="blog-single.php">Leia Mais</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <article class="entry">

              <div class="entry-img">
                <img src="assets/img/velho.png" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.php">Profissionais de 50 anos ou mais disputam espaço em tecnologia</a>
              </h2>

              <div class="entry-meta">

              </div>

              <div class="entry-content">
                <p> Quando você pensa em uma pessoa que é profissional de tecnologia em setores como TI ou programação, qual é a imagem mais comum na sua cabeça? É bem possível que seja a de alguém antenado, ágil, conhecedor das novidades do mercado, pronto para assumir desafios na carreira… e jovem.

                  Só que o mercado para profissionais de tecnologia dentro e fora do Brasil está longe de ser restrito a esse perfil. Há um grupo bastante presente no setor com mais de 50 anos, que encara tantos desafios e obstáculos quanto quem está no início de carreira — enfrentando ainda olhares de desconfiança, falta de oportunidades e até preconceito por parte de quem faz parte dessa indústria em alta.
                </p>
                <div class="read-more">
                  <a href="blog-single.php">Leia Mais</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <article class="entry">

              <div class="entry-img">
                <img src="assets/img/programador.jpg" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.php">Dia do programador: devs dão dicas para quem está iniciando na área</a>
              </h2>

              <div class="entry-meta">

                </ul>
              </div>

              <div class="entry-content">
                <p>Por trás de cada site e programa que você acessa no celular ou computador, casualmente ou no trabalho, existem milhões de códigos que passaram pelas mãos de desenvolvedores. A profissão é celebrada globalmente no Dia do Programador, comemorado em 12 ou 13 de setembro.

                  A data varia porque não foi escolhida aleatoriamente: a celebração ocorre no 256º dia do ano. O número em questão é conhecido no setor de desenvolvimento, já que representa fatores como a quantidade de valores distintos que podem ser representados com um byte de 8 bits, além de ser a potência mais elevada de 2 antes de 365 — o número total de dias do ano.
                  
                  Além de ser cheia de significados e números, a programação também conta com uma das áreas mais movimentadas no mercado de trabalho. Com crescimento de até 600% em alguns setores e dezenas de vagas sendo abertas com frequência, a profissão chama a atenção de quem está em busca de novas oportunidades na carreira.
                </p>
                <div class="read-more">
                  <a href="blog-single.php">Leia Mais</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <div class="blog-pagination">
              <ul class="justify-content-center">
                <li class="disabled"><i class="icofont-rounded-left"></i></li>
                <li><a href="#">1</a></li>
                <li class="active"><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#"><i class="icofont-rounded-right"></i></a></li>
              </ul>
            </div>

          </div><!-- End blog entries list -->

          <div class="col-lg-4">
            <div class="sidebar">

              <h3 class="sidebar-title">Pesquisa</h3>
              <div class="sidebar-item search-form">
                <form action="">
                  <input type="text">
                  <button type="submit"><i class="icofont-search"></i></button>
                </form>
              </div><!-- End sidebar search formn-->

              <h3 class="sidebar-title">Categories</h3>
              <div class="sidebar-item categories">
                <ul>
                  <li><a href="#">Geral <span>(25)</span></a></li>
                  <li><a href="#">Viagem<span>(5)</span></a></li>
                  <li><a href="#">Design <span>(22)</span></a></li>
                  <li><a href="#">Creatividade <span>(8)</span></a></li>
                  <li><a href="#">Educação<span>(14)</span></a></li>
                </ul>

              </div><!-- End sidebar categories-->

              <h3 class="sidebar-title">Recentes</h3>
              <div class="sidebar-item recent-posts">
                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-1.jpg" alt="">
                  <h4><a href="blog-single.php">Plataforma Crypto.com transfere R$ 2 bilhões por engano</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-2.jpg" alt="">
                  <h4><a href="blog-single.php">Elon Musk prevê recuperação do bitcoin, mas não por agora</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-3.jpg" alt="">
                  <h4><a href="blog-single.php">Twitter: senador dos EUA diz que pode tomar medidas contra Musk</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-4.jpg" alt="">
                  <h4><a href="blog-single.php">5 dos livros de ficção científica mais premiados do mundo</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-5.jpg" alt="">
                  <h4><a href="blog-single.php">Headset VR criado por cofundador da Oculus é capaz de matar o jogador</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>
              </div><!-- End sidebar recent posts-->


              </div><!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div><!-- End .row -->

      </div><!-- End .container -->

    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">


    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Links úteis</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="sistemaerp.php">Sistema ERP</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="serviços.php">Serviços</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Nossos Serviços</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Suporte de TI remoto</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Eletricidade Básica</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Configuração e Manutenção de PC</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Administração de rede de computadores</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contate-nos</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Sobre a Eletronic Arts</h3>
            <p>Somos uma Empresa focada em Tecnologia, que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eletronic Arts</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/ -->

      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>