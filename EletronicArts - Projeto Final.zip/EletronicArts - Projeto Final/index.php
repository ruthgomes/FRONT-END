<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> HOME </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ea.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Moderna - v2.0.0
  * Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="index.php"><span>Eletronic Arts</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu float-right d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="sistemaerp.php">Sistema ERP</a></li>
          <li><a href="serviços.php">Serviços</a></li>
          <li><a href="loja.php">Loja</a></li>
          <li><a href="time.php">Nosso time</a></li>
          <li><a href="blog.php">Notícias</a></li>
          <li><a href="contato.php">Contate-nos</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-cntent-center align-items-center">
    <div id="heroCarousel" class="container carousel carousel-fade" data-ride="carousel">

      <!-- Slide 1 -->
      <div class="carousel-item active">
        <div class="carousel-container">
          <h2 class="animated fadeInDown">Bem-vindo(a) ao <span>Eletronic Arts</span></h2>
          <p class="animated fadeInUp">Sejam todos bem-vindos ao Eletronic Arts, uma Empresa
            de serviços de informática e elétrica para a sua residência, prédio ou comércio,
            atendemos a domicílio e remotamente, caso você cliente não esteja no local dos nossos serviços.</p>
          <a href="" class="btn-get-started animated fadeInUp">Leia mais sobre nós</a>
        </div>
      </div>

      <!-- Slide 2 -->
      <div class="carousel-item">
        <div class="carousel-container">
          <h2 class="animated fadeInDown">Quais são os nossos valores?</h2>
          <p class="animated fadeInUp">Primeiro de tudo prezamos pela integridade de nossos técnicos e clientes,
            prezamos pela honestidade de nossos trabalhos e a segurança que passamos a todos aos nossos técnicos.</p>
          <a href="" class="btn-get-started animated fadeInUp">Leia mais sobre</a>
        </div>
      </div>

      <!-- Slide 3 -->
      <div class="carousel-item">
        <div class="carousel-container">
          <h2 class="animated fadeInDown">Nosso time</h2>
          <p class="animated fadeInUp">Nosso time é composto por 6 técnicos, 
            2 técnicos de informática que ajudam na parte de Help Desk, 
            2 técnicos empresarial, 
            2 técnicos de eletricidade básica e vendas.</p>
          <a href="" class="btn-get-started animated fadeInUp">Leia mais sobre</a>
        </div>
      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Services Section ======= -->
    <section class="services">
      <div class="container">

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4 class="title"><a href="">Sistema ERP</a></h4>
              <p class="description">É um software que permite automação de todos os processos em uma empresa, 
                ou seja, integra todos os setores (estoque, vendas, marketing, financeiro, recursos humanos, entre outros)
              em único lugar, o que facilita a comunicação e a análise de dados.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box icon-box-cyan">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="">Serviços</a></h4>
              <p class="description">É um sistema onde disponibilizamos os preços, a forma que trabalhamos com cada preço,
                o que fazemos em cada serviço e quais são os nossos serviços prestados pela nossa empresa.
              </p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box icon-box-green">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4 class="title"><a href="">Loja</a></h4>
              <p class="description">Em nossa loja disponibilizamos os preços de nossos produtos que vendemos para nossos clientes.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box icon-box-blue">
              <div class="icon"><i class="bx bx-world"></i></div>
              <h4 class="title"><a href="">Notícias</a></h4>
              <p class="description">Toda semana iremos atualizar as notícias que irão abranger as promoções, produtos novos, produtos expirados e tudo mais.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Why Us Section ======= -->
    <section class="why-us section-bg" data-aos="fade-up" date-aos-delay="200">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 video-box">
            <img src="assets/img/why-us.jpg" class="img-fluid" alt="">
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-6 d-flex flex-column justify-content-center p-5">

            <div class="icon-box">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Quem somos?</a></h4>
              <p class="description">Somos uma Empresa focada em Tecnologia, 
                que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="bx bx-gift"></i></div>
              <h4 class="title"><a href="">BENEFÍCIOS</a></h4>
              <p class="description">Temos os melhores profissionais do mercado, o melhor custo benefício e o melhor atendimento, fácil, rápido e seguro.</p>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Features Section ======= -->
    <section class="features">
      <div class="container">

        <div class="section-title">
          <h2>Recursos</h2>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5">
            <img src="assets/img/features-1.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-4">
            <h3>Rapido Atendimento</h3>
            <ul>
              <li><i class="icofont-check"></i> Resposta imediata.</li>
              <li><i class="icofont-check"></i> Segurança e desempelho.</li>
              <li><i class="icofont-check"></i> Facilitamos sua interação atraves do chat.</li>
            </ul>
          </div>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/features-2.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1">
            <h3>Alta Peformace</h3>
            <p>
              Nossa equipe trabalha todos os dias para que voce possa alcançar seus objetivos,
              facilitar sua vida e lhe proporcionar uma melhor peformace em sua empresa ou dia-a-dia.
              Não esquente a cabeça, conte conosco para resolver seus problemas, estaremos sempre a sua disposição,
              Sempre que voce precisar, estaremos aqui.
            </p>
          </div>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5">
            <img src="assets/img/features-3.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5">
            <h3>Comunicação Segura</h3>
            <p>Todas nossas comunicações são criptografadas de ponta a ponta para a proteção tanto de nossa equipe quanto de nossos clientes.</p>
            <ul>
              <li><i class="icofont-check"></i> Criptografia de ponta a ponta;</li>
              <li><i class="icofont-check"></i> Todas as conversas são salvas em nuvem onde apenas nossa empresa tem acesso;</li>
              <li><i class="icofont-check"></i> Proteção Atendente-Cliente;</li>
            </ul>
          </div>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/features-4.svg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1">
            <h3>Melhor Desempenho</h3>
            <p>
              Nosso site foi feito para atender melhor você, cliente, com informações de fácil entendimento e melhor especificação de nossos serviços,
              nossos serviços são feitos com o melhor desempenho e com a maior qualidade para a confiança de você, cliente.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h4>Quer receber mais notícias sobre nossos produtos ou relacionados? 
              Inscreva-se em nosso site!</h4>
            <p>Quer receber mais notícias sobre nossos produtos ou relacionados? Inscreva-se em nosso site!</p>
          </div>
          <div class="col-lg-6">
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Inscreva-se">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="sistemaerp.php">Sistema ERP</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="serviços.php">Serviços</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Suporte de TI remoto</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Eletricidade Básica</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Configuração e Manutenção de PC</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Administração de rede de computadores</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contate-nos</h4>
            <p>
              AV. Tefé, 2520 <br>
              Manaus/AM, Japiim<br>
              Brasil <br><br>
              <strong>Telefone:</strong> +55(92)98119-7243 <br>
              <strong>Email:</strong> esqueciminhasenhaARROBApontocom<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Sobre a Eletronic Arts</h3>
            <p>Somos uma Empresa focada em Tecnologia, que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eletronic Arts</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/ -->
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>