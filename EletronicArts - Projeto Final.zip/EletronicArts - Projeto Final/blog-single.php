<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>EA</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ea.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Moderna - v2.0.0
  * Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="index.php"><span>Eletronic Arts</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu float-right d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="sistemaerp.php">Sistema ERP</a></li>
          <li><a href="serviços.php">Serviços</a></li>
          <li><a href="loja.php">Loja</a></li>
          <li><a href="time.php">Nosso time</a></li>
          <li class="active"><a href="blog.php">Notícias</a></li>
          <li><a href="contato.php">Contate-nos</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Blog Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Notícias</h2>

          <ol>
            <li><a href="index.php">Home</a></li>
            <li><a href="blog.php">Notícias</a></li>
          </ol>
        </div>

      </div>
    </section><!-- End Blog Section -->

    <!-- ======= Blog Section ======= -->
    <section class="blog" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">
      <div class="container">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry entry-single">
              <div class="entry-img">
                <img src="assets/img/msp.png" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href="blog-single.php">MSP Summit: tudo sobre o evento para profissionais de TI</a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="blog-single.php">John Doe</a></li>
                  <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="blog-single.php"><time datetime="2020-01-01">Jan 1, 2020</time></a></li>
                  <li class="d-flex align-items-center"><i class="icofont-comment"></i> <a href="blog-single.php">12 Comments</a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  Você conhece o MSP Summit? Ele é um encontro anual que busca fomentar networking e troca de conhecimento entre profissionais de Tecnologia da Informação (TI) e contou com a participação de 1,2 mil inscritos em 2021. Neste ano, o evento volta ao seu formato presencial, que acontecerá em São Paulo.

O recente relatório da Brazilian Software Market Study — Overview and Trends 2022 divulgou que a projeção de crescimento para o mercado de TI em 2022 é de 14,3% e, além disso, os investimentos no setor continuam em expansão. 

Assim, a Pesquisa anual do uso de TI 2022, conduzida pela Fundação Getulio Vargas (FGV), apontou um crescimento nos investimentos que as empresas estão fazendo no setor de TI. Em 2021, a média do volume de investimentos em TI por essas empresas foi de 8,2%, enquanto o realizado neste ano foi de 8,7%.

A pandemia só reforçou e acelerou a necessidade de transformação digital nas empresas, que precisaram aderir a modelos de trabalho mais digitalizados e eletrônicos. Portanto, aquelas que ainda não viam a necessidade de contar com bons hardwares, softwares e prestadores de serviços de TI passaram a buscar a terceirização das demandas técnicas e, claro, contar com empresas e profissionais especializados nessa assistência.

Nesse sentido, mesmo diante do cenário enfrentado nos últimos anos de pandemia, cerca de 40% dos prestadores de serviços de TI que responderam à Pesquisa ADDEE — Mercado MSP Brasileiro 2021 afirmaram ser um bom momento para estar no mercado de TI. Esse estudo anual retrata o cenário das PMEs de serviços de TI do Brasil.


                </p>


                <p>
                  Com isso, o MSP Summit se tornou uma oportunidade de aprender com especialistas dos mercados nacional e internacional. Em sua 8ª edição, o evento acontecerá em 27 e 28 de outubro de 2022, no Centro de Convenções Rebouças. 

A organização do evento planeja ter três trilhas simultâneas de conhecimento para os participantes, envolvendo painéis com prestadores de serviços de TI, palestras internacionais com especialistas como Stefan Voss, VP of Product Management da N-able, além de conteúdos sobre gestão estratégica, automação, inovação e atendimento ao cliente.

Outros nomes fortes do mercado, como Marcelo Martins, diretor de tecnologia (CTO) do GetNinjas, e Luís Rasquilha, diretor-executivo (CEO) do Ecossistema Inova, estão confirmados nas trilhas de conhecimento. Martins é especialista em tangibilizar estratégias de negócios e transformá-las em tecnologias e soluções eficazes, enquanto Rasquilha é autoridade no assunto de tendências e inovações disruptivas. 
                </p>

                <h3>Prestadores de serviços de TI precisam ser especialistas</h3>
                <p>A transformação digital não foi um “divisor de águas” apenas para as empresas, que estavam desatualizadas, mas também evidenciou a importância de contar com especialistas. Por isso, temas como segurança da informação, ransomware e proteção de dados estiveram em maior evidência nos últimos anos. Dessa forma, os prestadores de serviços de TI que buscam se destacar no mercado precisam dominar esses conceitos, tanto na técnica quanto na prática.
                </p>
                <img src="assets/img/msp2.png" class="img-fluid" alt="">

                <h3>O MSP Summit é tradição</h3>
                <p>
                  O evento já se tornou uma tradição entre a comunidade de MSPs e, neste ano, terá a maior edição presencial, estimando mais de 600 profissionais reunidos no Centro de Convenções Rebouças.

Nos primeiros anos, o evento era exclusivo para parceiros da ADDEE, mas, com a necessidade de empoderar os profissionais do setor de TI, a organização abriu o evento para o público em geral. Em 2021, na edição virtual do evento devido à pandemia de covid-19, o sucesso do MSP Summit fez que alguns inscritos comprassem ingresso para a edição de 2022 antes mesmo da data oficial ser divulgada, de acordo com Luís Montanari, gerente de Marketing e Vendas da ADDEE.

O evento é feito para todos os prestadores de serviços de TI que buscam se especializar, aprender com profissionais que são autoridades e fazer networking, oferecendo mais de 12 horas de conteúdo e uma feira de negócios com mais de dez expositores.
                </p>

              </div>

              <div class="entry-footer clearfix">
                <div class="float-left">
                  <i class="icofont-folder"></i>
                  <ul class="cats">
                    <li><a href="#"></a></li>
                  </ul>

                  <i class="icofont-tags"></i>
                  <ul class="tags">

                  </ul>
                </div>

                <div class="float-right share">
                  <a href="" title="Share on Twitter"><i class="icofont-twitter"></i></a>
                  <a href="" title="Share on Facebook"><i class="icofont-facebook"></i></a>
                  <a href="" title="Share on Instagram"><i class="icofont-instagram"></i></a>
                </div>

              </div>

            </article><!-- End blog entry -->

            <div class="blog-author clearfix">
              <img src="assets/img/team/ruth.jpeg" class="rounded-circle float-left" alt="">
              <h4>Jane Smith</h4>
              <div class="social-links">
                <a href="https://twitters.com/#"><i class="icofont-twitter"></i></a>
                <a href="https://facebook.com/#"><i class="icofont-facebook"></i></a>
                <a href="https://instagram.com/#"><i class="icofont-instagram"></i></a>
              </div>
              <p>
                Itaque quidem optio quia voluptatibus dolorem dolor. Modi eum sed possimus accusantium. Quas repellat
                voluptatem officia numquam sint aspernatur voluptas. Esse et accusantium ut unde voluptas.
              </p>
            </div><!-- End blog author bio -->

            <div class="blog-comments">

              <h4 class="comments-count">6 Comentários</h4>

              <div id="comment-1" class="comment clearfix">
                <img src="assets/img/testimonials/joyce.jpeg" class="comment-img  float-left" alt="">
                <h5><a href="">Georgia Reader</a> <a href="#" class="reply"><i class="icofont-reply"></i> Reply</a></h5>
                <time datetime="2020-01-01">01 Jan, 2020</time>
                <p>
                  Et rerum totam nisi. Molestiae vel quam dolorum vel voluptatem et et. Est ad aut sapiente quis molestiae
                  est qui cum soluta.
                  Vero aut rerum vel. Rerum quos laboriosam placeat ex qui. Sint qui facilis et.
                </p>
              </div><!-- End comment #1 -->

              <div id="comment-2" class="comment clearfix">
                <img src="assets/img/testimonials/hugosousa.jpeg" class="comment-img  float-left" alt="">
                <h5><a href="">Aron Alvarado</a> <a href="#" class="reply"><i class="icofont-reply"></i> Reply</a></h5>
                <time datetime="2020-01-01">01 Jan, 2020</time>
                <p>
                  Ipsam tempora sequi voluptatem quis sapiente non. Autem itaque eveniet saepe. Officiis illo ut beatae.
                </p>

                <div id="comment-reply-1" class="comment comment-reply clearfix">
                  <img src="assets/img/testimonials/jhonk.jpeg" class="comment-img  float-left" alt="">
                  <h5><a href="">Lynda Small</a> <a href="#" class="reply"><i class="icofont-reply"></i> Reply</a></h5>
                  <time datetime="2020-01-01">01 Jan, 2020</time>
                  <p>
                    Enim ipsa eum fugiat fuga repellat. Commodi quo quo dicta. Est ullam aspernatur ut vitae quia mollitia
                    id non. Qui ad quas nostrum rerum sed necessitatibus aut est. Eum officiis sed repellat maxime vero
                    nisi natus. Amet nesciunt nesciunt qui illum omnis est et dolor recusandae.
                    Recusandae sit ad aut impedit et. Ipsa labore dolor impedit et natus in porro aut. Magnam qui cum.
                    Illo similique occaecati nihil modi eligendi. Pariatur distinctio labore omnis incidunt et illum.
                    Expedita et dignissimos distinctio laborum minima fugiat.
                    Libero corporis qui. Nam illo odio beatae enim ducimus. Harum reiciendis error dolorum non autem
                    quisquam vero rerum neque.
                  </p>

                  <div id="comment-reply-2" class="comment comment-reply clearfix">
                    <img src="assets/img/testimonials/felipe.jpeg" class="comment-img  float-left" alt="">
                    <h5><a href="">Sianna Ramsay</a> <a href="#" class="reply"><i class="icofont-reply"></i> Reply</a>
                    </h5>
                    <time datetime="2020-01-01">01 Jan, 2020</time>
                    <p>
                      Et dignissimos impedit nulla et quo distinctio ex nemo. Omnis quia dolores cupiditate et. Ut unde
                      qui eligendi sapiente omnis ullam. Placeat porro est commodi est officiis voluptas repellat quisquam
                      possimus. Perferendis id consectetur necessitatibus.
                    </p>
                  </div><!-- End comment reply #2-->

                </div><!-- End comment reply #1-->

              </div><!-- End comment #2-->

              <div id="comment-3" class="comment clearfix">
                <img src="assets/img/testimonials/preto.jpeg" class="comment-img  float-left" alt="">
                <h5><a href="">Nolan Davidson</a> <a href="#" class="reply"><i class="icofont-reply"></i> Reply</a></h5>
                <time datetime="2020-01-01">01 Jan, 2020</time>
                <p>
                  Distinctio nesciunt rerum reprehenderit sed. Iste omnis eius repellendus quia nihil ut accusantium
                  tempore. Nesciunt expedita id dolor exercitationem aspernatur aut quam ut. Voluptatem est accusamus iste
                  at.
                  Non aut et et esse qui sit modi neque. Exercitationem et eos aspernatur. Ea est consequuntur officia
                  beatae ea aut eos soluta. Non qui dolorum voluptatibus et optio veniam. Quam officia sit nostrum
                  dolorem.
                </p>
              </div><!-- End comment #3 -->

              <div id="comment-4" class="comment clearfix">
                <img src="assets/img/team/marcelob.jpg" class="comment-img  float-left" alt="">
                <h5><a href="">Kay Duggan</a> <a href="#" class="reply"><i class="icofont-reply"></i> Reply</a></h5>
                <time datetime="2020-01-01">01 Jan, 2020</time>
                <p>
                  Dolorem atque aut. Omnis doloremque blanditiis quia eum porro quis ut velit tempore. Cumque sed quia ut
                  maxime. Est ad aut cum. Ut exercitationem non in fugiat.
                </p>

              </div><!-- End comment #4 -->

              <div class="reply-form">
                <h4>Leave a Reply</h4>
                <p>Your email address will not be published. Required fields are marked * </p>
                <form action="">
                  <div class="row">
                    <div class="col-md-6 form-group">
                      <input name="name" type="text" class="form-control" placeholder="Your Name*">
                    </div>
                    <div class="col-md-6 form-group">
                      <input name="email" type="text" class="form-control" placeholder="Your Email*">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col form-group">
                      <input name="website" type="text" class="form-control" placeholder="Your Website">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col form-group">
                      <textarea name="comment" class="form-control" placeholder="Your Comment*"></textarea>
                    </div>
                  </div>
                  <button type="submit" class="btn btn-primary">Post Comment</button>
                </form>
              </div>

            </div><!-- End blog comments -->

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar">

              <h3 class="sidebar-title">Pesquisa</h3>
              <div class="sidebar-item search-form">
                <form action="">
                  <input type="text">
                  <button type="submit"><i class="icofont-search"></i></button>
                </form>
              </div><!-- End sidebar search formn-->

              <h3 class="sidebar-title">Categorias</h3>
              <div class="sidebar-item categories">
                <ul>
                  <li><a href="#">Geral <span>(25)</span></a></li>
                  <li><a href="#">Viagem <span>(5)</span></a></li>
                  <li><a href="#">Design <span>(22)</span></a></li>
                  <li><a href="#">Creatividade <span>(8)</span></a></li>
                  <li><a href="#">Educação <span>(14)</span></a></li>
                </ul>

              </div><!-- End sidebar categories-->

              <h3 class="sidebar-title">Recentes</h3>
              <div class="sidebar-item recent-posts">
                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-1.jpg" alt="">
                  <h4><a href="blog-single.php">Plataforma Crypto.com transfere R$ 2 bilhões por engano</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-2.jpg" alt="">
                  <h4><a href="blog-single.php">Elon Musk prevê recuperação do bitcoin, mas não por agora</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-3.jpg" alt="">
                  <h4><a href="blog-single.php">Twitter: senador dos EUA diz que pode tomar medidas contra Musk</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-4.jpg" alt="">
                  <h4><a href="blog-single.php">5 dos livros de ficção científica mais premiados do mundo</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/recent-posts-5.jpg" alt="">
                  <h4><a href="blog-single.php">Headset VR criado por cofundador da Oculus é capaz de matar o jogador</a></h4>
                  <time datetime="2020-01-01">Nov 21, 2022</time>
                </div>
              </div><!-- End sidebar recent posts-->



              </div><!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div><!-- End row -->

      </div><!-- End container -->

    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h4>Quer receber mais notícias sobre nossos produtos ou relacionados? Inscreva-se em nosso site!</h4>
            <p>Para mais dúvidas, elogios ou críticas nos mande um e-mail</p>
          </div>
          <div class="col-lg-6">
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Links úteis</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="sistemaerp.php">Sistema ERP</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="serviços.php">Serviços</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Nossos Serviços</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Suporte de TI remoto</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Eletricidade Básica</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Configuração e Manutenção de PC</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Administração de rede de computadores</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contate-nos</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Sobre a Eletronic Arts</h3>
            <p>Somos uma Empresa focada em Tecnologia, que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eletronic Arts</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/ -->

      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>