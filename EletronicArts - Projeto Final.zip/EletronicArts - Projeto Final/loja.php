<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title> Loja </title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/ea.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Moderna - v2.0.0
  * Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="index.php"><span>Eletronic Arts</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu float-right d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="sistemaerp.php">Sistema ERP</a></li>
          <li><a href="serviços.php">Serviços</a></li>
          <li class="active"><a href="loja.php">Loja</a></li>
          <li><a href="time.php">Nosso time</a></li>
          <li><a href="blog.php">Notícias</a></li>
          <li><a href="contato.php">Contate-nos</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Our Portfolio Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Loja</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Nossos Produtos</li>
          </ol>
        </div>

      </div>
    </section><!-- End Our Portfolio Section -->

    <!-- ======= Portfolio Section ======= -->
    <section class="portfolio">
      <div class="container">

        <div class="row">
          <div class="col-lg-12">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">Todos</li>
              <li data-filter=".filter-app">Informática</li>
              <li data-filter=".filter-card">Elétrica</li>
              <li data-filter=".filter-web">Diversos</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

          <!--I N F O R M Á T I C A-->
          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/cooler.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/cooler.jpg" data-gall="portfolioGallery" class="venobox" title="Cooler Corsair">Water Cooler Corsair Icue H150i RGB - R$1.288,99</a></h3>
                <a href="assets/img/cooler.jpg" data-gall="portfolioGallery" class="venobox" title="Cooler Corsair"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/teclado.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/teclado.jpg" data-gall="portfolioGallery" class="venobox" title="Teclado Mecanico">Teclado Mecânico Redragon Harpe- R$179,90</a></h3>
                <a href="assets/img/teclado.jpg" data-gall="portfolioGallery" class="venobox" title="Teclado Mecanico"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/panel.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/panel.jpg" data-gall="portfolioGallery" class="venobox" title="Patch Panel">Patch Panel - R$349,90</a></h3>
                <a href="assets/img/panel.jpg" data-gall="portfolioGallery" class="venobox" title="Patch Panel"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/i3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/i3.jpg" data-gall="portfolioGallery" class="venobox" title="Intel Core i3 10100F">Intel Core i3 10100F - R$519,90</a></h3>
                <a href="assets/img/i3.jpg" data-gall="portfolioGallery" class="venobox" title="Intel Core i3 10100F"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/i5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/i5.jpg" data-gall="portfolioGallery" class="venobox" title="Intel Core i5 10400F">Intel Core i5 10400F - R$839,99</a></h3>
                <a href="assets/img/i5.jpg" data-gall="portfolioGallery" class="venobox" title="Intel Core i5 10400F"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/memorias.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/memorias.jpg" data-gall="portfolioGallery" class="venobox" title="Memória Ram 16gb Asgard Loki">Memória Ram 16gb Asgard Loki - R$359,90</a></h3>
                <a href="assets/img/memorias.jpg" data-gall="portfolioGallery" class="venobox" title="Memória Ram 16gb Asgard Loki"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/ssd.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/ssd.jpg" data-gall="portfolioGallery" class="venobox" title="SSD Gamer Ninja Shuriken 240gb">SSD Gamer Ninja Shuriken 240GB - R$209,90</a></h3>
                <a href="assets/img/ssd.jpg" data-gall="portfolioGallery" class="venobox" title="SSD Gamer Ninja Shuriken 240gb"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/placadevideo.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/placadevideo.jpg" data-gall="portfolioGallery" class="venobox" title="RTX 3080 12GB">EVGA GeForce RTX 3080 12GB GDDR6X - R$8.299,99</a></h3>
                <a href="assets/img/placadevideo.jpg" data-gall="portfolioGallery" class="venobox" title="RTX 3080 12GB"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/placamae.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/placamae.jpg" data-gall="portfolioGallery" class="venobox" title="Placa Mae">Placa Mãe Gigabyte B450M Aorus Elite - R$935,90</a></h3>
                <a href="assets/img/placamae.jpg" data-gall="portfolioGallery" class="venobox" title="Placa Mae"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/gab.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/gab.jpg" data-gall="portfolioGallery" class="venobox" title="Gabinete">Gabinete Gamer Ninja Bee Mid Tower - R$198,99</a></h3>
                <a href="assets/img/gab.jpg" data-gall="portfolioGallery" class="venobox" title="Gabinete"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/hd.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/hd.jpg" data-gall="portfolioGallery" class="venobox" title="HD 1TB">HD 1TB Seagate Barracuda Interno 3.5 Sata3 - R$249,00</a></h3>
                <a href="assets/img/hd.jpg" data-gall="portfolioGallery" class="venobox" title="HD 1TB"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-app">
            <div class="portfolio-item">
              <img src="assets/img/cabo.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/cabo.jpg" data-gall="portfolioGallery" class="venobox" title="Cabo de Rede Par Trançado">Cabo de Rede Cat6 60 Metros - R$90,00</a></h3>
                <a href="assets/img/cabo.jpg" data-gall="portfolioGallery" class="venobox" title="Cabo de Rede Par Trançado"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>  
          <!--I N F O R M Á T I C A-->
          <!--E L É T R I C A-->
          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/ele1.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/ele1.jpg" data-gall="portfolioGallery" class="venobox" title="Camera Intelbras">Camera Intelbras Multi HD 1080p - R$769,00</a></h3>
                <a href="assets/img/ele1.jpg" data-gall="portfolioGallery" class="venobox" title="Camera Intelbras"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/trava.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/trava.jpg" data-gall="portfolioGallery" class="venobox" title="Trava">Trava Eletrônica - R$419,00</a></h3>
                <a href="assets/img/trava.jpg" data-gall="portfolioGallery" class="venobox" title="Trava"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/ele3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/ele3.jpg" data-gall="portfolioGallery" class="venobox" title="Tomada">Tomada - R$12,00</a></h3>
                <a href="assets/img/ele3.jpg" data-gall="portfolioGallery" class="venobox" title="Tomada"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/lamp.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/lamp.jpg" data-gall="portfolioGallery" class="venobox" title="Lampada de Led">Lâmpada Led Avant 4.8W Bulbo Pera Bivolt - R$7,99</a></h3>
                <a href="assets/img/lamp.jpg" data-gall="portfolioGallery" class="venobox" title="Lampada de Led"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/fibra.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/fibra.jpg" data-gall="portfolioGallery" class="venobox" title="Cabo de Fibra">Cabo de Fibra Optica Evus - R$725,20</a></h3>
                <a href="assets/img/fibra.jpg" data-gall="portfolioGallery" class="venobox" title="Cabo de Fibra"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/cerca.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/cerca.jpg" data-gall="portfolioGallery" class="venobox" title="Cerca Elétrica">Kit Cerca Elétrica Intelbras - R$1.808,53</a></h3>
                <a href="assets/img/cerca.jpg" data-gall="portfolioGallery" class="venobox" title="Cerca Elétrica"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/quadro.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/quadro.jpg" data-gall="portfolioGallery" class="venobox" title="Quadro Distribuição">Quadro de distruição e proteção 48 polos Volt 160A - R$828,23</a></h3>
                <a href="assets/img/quadro.jpg" data-gall="portfolioGallery" class="venobox" title="Quadro Distribuição"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/alarme.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/alarme.jpg" data-gall="portfolioGallery" class="venobox" title="Alarme">Alarme Residencial sem fio com sensor de movimento - R$50,00</a></h3>
                <a href="assets/img/alarme.jpg" data-gall="portfolioGallery" class="venobox" title="Alarme"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/dis.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/dis.jpg" data-gall="portfolioGallery" class="venobox" title="Disjuntor">Disjuntor de energia para caixa de distribuição - R$150,50</a></h3>
                <a href="assets/img/dis.jpg" data-gall="portfolioGallery" class="venobox" title="Disjuntor"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/caboc.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/caboc.jpg" data-gall="portfolioGallery" class="venobox" title="Cabo de cobre">Fio Cabo de Cobre Rígido Aterramento 6mm com 100 metros - R$800,90</a></h3>
                <a href="assets/img/caboc.jpg" data-gall="portfolioGallery" class="venobox" title="Cabo de cobre"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/conduite.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/conduite.jpg" data-gall="portfolioGallery" class="venobox" title="Conduite">Conduite Eletroduto 3/4 Reforçado Preto 50 Metros Dual - R$40,99</a></h3>
                <a href="assets/img/conduite.jpg" data-gall="portfolioGallery" class="venobox" title="Conduite"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-card">
            <div class="portfolio-item">
              <img src="assets/img/canaleta.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/canaleta.jpg" data-gall="portfolioGallery" class="venobox" title="Canaleta PVC">Canaleta PVC Perfurada 50x80x2000mm Dutoplast - R$48,50</a></h3>
                <a href="assets/img/canaleta.jpg" data-gall="portfolioGallery" class="venobox" title="Canaleta PVC"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>
          <!--E L É T R I C A-->
          <!--D I V E R S O S-->
          <div class="col-lg-4 col-md-6 filter-web">
            <div class="portfolio-item">
              <img src="assets/img/win10.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/win10.jpg" data-gall="portfolioGallery" class="venobox" title="Windows">Windows 10 - R$229,00</a></h3>
                <a href="assets/img/win10.jpg" data-gall="portfolioGallery" class="venobox" title="Windows"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-web">
            <div class="portfolio-item">
              <img src="assets/img/office.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/office.jpg" data-gall="portfolioGallery" class="venobox" title="Office">Pacote Office - R$449,00</a></h3>
                <a href="assets/img/office.jpg" data-gall="portfolioGallery" class="venobox" title="Office"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-web">
            <div class="portfolio-item">
              <img src="assets/img/kas.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/kas.jpg" data-gall="portfolioGallery" class="venobox" title="Karspersky">Karspersky - R$50,00</a></h3>
                <a href="assets/img/kas.jpg" data-gall="portfolioGallery" class="venobox" title="Karspersky"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-web">
            <div class="portfolio-item">
              <img src="assets/img/mcafee.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/mcafee.jpg" data-gall="portfolioGallery" class="venobox" title="McAfee">McAfee - R$65,00</a></h3>
                <a href="assets/img/mcafee.jpg" data-gall="portfolioGallery" class="venobox" title="McAfee"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-web">
            <div class="portfolio-item">
              <img src="assets/img/bit.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/bit.jpg" data-gall="portfolioGallery" class="venobox" title="Bitdefender">Bitdefender - R159,99</a></h3>
                <a href="assets/img/bit.jpg" data-gall="portfolioGallery" class="venobox" title="Bitdefender"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 filter-web">
            <div class="portfolio-item">
              <img src="assets/img/corel.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h3><a href="assets/img/corel.jpg" data-gall="portfolioGallery" class="venobox" title="CorelDRAW">CorelDRAW Graphics Suite 2021 - R2.950,50</a></h3>
                <a href="assets/img/corel.jpg" data-gall="portfolioGallery" class="venobox" title="CorelDRAW"><i class="icofont-plus"></i></a>
              </div>
            </div>
          </div>
          <!--D I V E R S O S-->

        </div>

      </div>
    </section><!-- End Portfolio Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h4>Quer receber mais notícias sobre nossos produtos ou relacionados? Inscreva-se em nosso site!</h4>
            <p>Para mais dúvidas, elogios ou críticas nos mande um e-mail</p>
          </div>
          <div class="col-lg-6">
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Links úteis</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="sistemaerp.php">Sistema ERP</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="serviços.php">Serviços</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Nossos Serviços</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Suporte de TI remoto</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Eletricidade Básica</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Configuração e Manutenção de PC</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Administração de rede de computadores</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contate-nos</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Sobre a Eletronic Arts</h3>
            <p>Somos uma Empresa focada em Tecnologia, que busca melhorar a vida dos nossos clientes a ter uma melhor experiência e facilidade no dia a dia.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eletronic Arts</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/ -->

      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>